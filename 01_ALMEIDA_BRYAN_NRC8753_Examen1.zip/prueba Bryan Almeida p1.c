//NOMBRE:BRYAN ALMEIDA
//CARRERA: ELECTRONICA Y AUT
//CURSO (NRC):8753
//FECHA: 5 /06/ 2023
#include<stdio.h>
#include<math.h>

int main(){
	
	int producto;
	int precio;
	int recarga;
	int saldo;
	int vuelto;
	
printf ("La maquina solo dispone de dos productos actualmente\n");
printf ("La maquina se ha quedado con dos tipos de productos (Gaseosa y Galleta)\n");
printf ("Presione 1 para una galleta:\n su precio es de 0.35ctvs");
printf ("\nPresione 2 para una gaseosa:\n su precio es de 0.55ctvs\n");
printf ("\nPresione 3 para salir\n");
scanf ("\n%i",& producto);
printf ("\nPuede ingresar monedas de 5,10,25 y 50ctvs\n");


switch (producto){
case 1:  
printf ("\nHa seleccionado galleta\n"); printf ("\ningrese la recarga de 0.35ctvs\n"); 
scanf("\n%i",& saldo);
printf ("\nSu recarga es de:\n%i",saldo); 
if (saldo>55)
vuelto=saldo-55;
printf ("\nSu vuelto es de:\n%d",vuelto); 
break;
case 2:
printf ("\nHa seleccionado Gaseosa\n"); printf ("\ningrese la recarga de 0.55ctvs\n"); 
scanf("\n%i",& saldo);
printf ("\nSu recarga es de:\n%i",saldo); 
if (saldo>35)
vuelto==saldo-35;

printf ("\nSu vuelto es de :\n%d",vuelto); 
break;
case 3: printf ("\nHa salido exitosamente\n");
default: 
printf ("\nProducto no disponible\n");
}
while(producto) {
}


}

