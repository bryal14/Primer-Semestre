//division de dos numeros con retorno de valor 
#include <stdio.h>
int division(int n1, int n2);

int main(){
	int n1,n2;
	int result;
	
printf ("*****************UNIVERSIDAD DE LAS FUERZAS ARMADAS*****************");
	printf ("\n*******CALCULADORA DE DIVISIONES**********\n");
	
	
	printf ("\n\nIngrese los numeros a realizar la operacion\n");
	scanf ("%d",&n1);
	scanf ("%d",&n2);
	result=division(n1,n2);
	printf ("El resultado de la multiplicacion es %i ",result);
	
	return 0;
}

int division(int n1, int n2){
	int result;
		
	result=n1/n2;
	
	return result;
}
