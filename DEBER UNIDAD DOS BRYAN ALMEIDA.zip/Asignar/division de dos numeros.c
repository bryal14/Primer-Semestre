//division de dos numeros

#include <stdio.h>
void division();

int main(){

	division();
	return 0;
}

void division(){
	int n1,n2,result;
	printf ("*****************UNIVERSIDAD DE LAS FUERZAS ARMADAS*****************");
	printf ("\n*******CALCULADORA DE DIVISIONES**********\n");
	
	
	printf ("\n\nIngrese los numeros a realizar la operacion\n");
	scanf ("%d",&n1);
	scanf ("%d",&n2);
	
	result=n1/n2;
	printf ("\nEl resultado de la division es:%d",result);
}
