//multiplicacion de dos numeros con retorno de valor

//mutliplicacion de dos numeros 

#include <stdio.h>

int multi(int n1, int n2);

int main(){
		
	int n1,n2;
	int result;
	
	printf ("****************UNIVERSIDAD DE LAS FUERZAS ARMADAS****************");
	printf ("\n******CALCULADORA DE DIVISIONES*********");
	printf ("\n\nIngrese dos numeros\n");
	scanf("%i",&n1);
	scanf("%i",&n2);
	result=multi(n1,n2);
	printf ("El resultado de la multiplicacion es %i", result);
	
return 0;	
}

int multi(int n1,int n2){

	int result;
	
	result = n1*n2;
	
	return result;
}


