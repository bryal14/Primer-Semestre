//mutliplicacion de dos numeros 
#include <stdio.h>

void multi();

int main(){
	multi();
return 0;	
}

void multi(){
	int n1,n2,result;
	printf ("****************UNIVERSIDAD DE LAS FUERZAS ARMADAS****************");
	printf ("\n******CALCULADORA DE DIVISIONES*********");
	
	printf ("\n\nIngrese dos numeros\n");
	scanf("%i",&n1);
	scanf("%i",&n2);
	result = n1*n2;
	printf ("El resultado es:%i ", 	result);
}
