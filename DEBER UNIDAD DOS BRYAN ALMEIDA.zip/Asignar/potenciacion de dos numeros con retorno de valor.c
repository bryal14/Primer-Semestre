//potenciacion de dos numeros con retorno de valor
#include <stdio.h>

int potenciacion(int n1, int n2);

int main(){
	int n1;
	int n2;
	int result; 
	
	printf ("**********UNIVERSIDAD DE LAS FUERZAS ARMADAS*************\n\n");
	printf ("**********Calculadora de potencias**********\n\n");
	printf ("Ingrese la Base de la potencia:\n");
	scanf ("%i",&n1);
	printf ("Ingrese el exponente de la operacion: ");
	scanf ("%i",&n2);
	result=potenciacion(n1,n2);
	printf ("El resultado de la potencia es %i ", result);
	
	return 0;	
}

int potenciacion(int n1, int n2){
	
	int result;

	result=pow (n1,n2);
	
	return result;
}
