#include <stdio.h>

void potenciacion();

int main(){
	
	potenciacion();
	return 0;	
}

void potenciacion(){
	printf ("**********UNIVERSIDAD DE LAS FUERZAS ARMADAS*************\n\n");
	printf ("**********Calculadora de potencias**********\n\n");

	int n1,n2,result;

		printf ("Ingrese la Base de la potencia:\n");
		scanf ("%i",&n1);
		printf ("Ingrese el exponente de la operacion: ");
		scanf ("%i",&n2);
		result=pow (n1,n2);
		printf ("\nEl resultado de la operacion es:%i",result);
}
