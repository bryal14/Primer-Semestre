//resta de dos numeros con retorno de valor


#include <stdio.h>

int resta(int n1,int n2);

int main (){
	int n1,n2;
	int result;
	
	printf ("*****************UNIVERSIDAD DE LAS FUERZAS ARMADAS*****************");
	printf ("*******CALCULADORA DE RESTAS**********");
	printf ("\n\nIngrese dos numeros\n");
	scanf ("\n%i",&n1);
	scanf ("\n%i",&n2);
	
	result=resta(n1,n2);
	printf ("El resultado de la resta es %i",result);
	return 0;	
}

int resta(int n1,int n2){
	int result;
	result=n1-n2;

	return result;

}
