//resta de dos numeros 

#include <stdio.h>

void resta();

int main (){
	
	resta();
	return 0;	
}

void resta(){
	int n1,n2,result;
	printf ("*****************UNIVERSIDAD DE LAS FUERZAS ARMADAS*****************");
	printf ("*******CALCULADORA DE RESTAS**********");
	printf ("\n\nIngrese dos numeros\n");
	scanf ("\n%i",&n1);
	scanf ("\n%i",&n2);
	result=n1-n2;
	printf ("El resultado de la resta es: %i",result);
}
