//suma de dos numeros con retorno de valor
//suma de dos numeros 
#include<stdio.h>

int suma(int n1,int n2);

int main(){
 	int n1,n2;
	int result;
	 
	 printf ("*****************UNIVERSIDAD DE LAS FUERZAS ARMADAS*****************");
	printf ("******CALCULADORA DE SUMAS***********");
	printf  ("\n\nIngrese los numeros los cuales seran sumados\n ");
	scanf ("%i",&n1);		
	scanf ("%i",&n2);
	
	result=suma(n1,n2);
	printf ("El resultado de la suma es %i", result);	
	return 0;
}

int suma(int n1,int n2){
	
	int result;
	
	result=n1+n2;
	
	return result;		
}
