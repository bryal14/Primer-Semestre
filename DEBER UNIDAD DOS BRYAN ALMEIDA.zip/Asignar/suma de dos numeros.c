//suma de dos numeros 
#include<stdio.h>

void suma();

int main(){
 suma();
	return 0;
}

void suma(){
puts ("*****************UNIVERSIDAD DE LAS FUERZAS ARMADAS*****************");
puts ("******CALCULADORA DE SUMAS***********");
	int n1,n2,result;
		puts ("\n\nIngrese los numeros los cuales seran sumados\n ");
	scanf ("%i",&n1);		
	scanf ("%i",&n2);
	result=n1+n2;
	printf ("El resultado es:%i",	result);		
}
