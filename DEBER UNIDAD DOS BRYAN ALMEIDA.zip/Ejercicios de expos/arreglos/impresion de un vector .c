//impresion de un vector mediante un ciclo for 
#include <stdio.h>
void vector ();

int main(){
    vector ();
    return 0;
}
void vector(){
	int vector [8]={1,2,3,4,5,6,7,8};
    int i;
    
    for (i=0 ; i<8 ;i++){
        printf ("%d",vector[i]);
    }
}
