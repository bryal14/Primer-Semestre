//impresion de un vector de 8 caracteres mediante el ingreso por teclado 

#include<stdio.h>

void vector(); 

int main(){
	vector();
	return 0;
}
void vector(){
	int vector[8];
	int i;
	
	printf ("Ingrese los numeros del  vector\n");
	for (i=0; i<8;i++){
		i+1;
		scanf("%d",&vector[i]);
	}
	
	printf ("El vector es:\n");
	for (i=0;i<8;i++){
		printf ("%d",vector[i]);
	}
}
