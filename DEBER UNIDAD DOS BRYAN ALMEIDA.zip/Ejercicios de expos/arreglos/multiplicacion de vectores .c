//multiplicar vectores de dimension dos 

#include <stdio.h>

void multi(int v1[3], int v2[3], int vr[3]);

int main (){
	int v1[3]={1,2,3,};
	int v2[3]={2,3,4};
	int vr[3];
	int i;
	
	multi(v1,v2,vr);
	
	printf("El vector uno es:\n");
	for (i=0;i<3;i++){
		printf ("%d ",v1[i]);
	}
	
	printf ("\n\nEl vector dos es:\n");
	for (i=0;i<3;i++){
		printf ("%d ",v2[i]);
	}
	
	printf ("\n\nLa multiplicacion de vectores es\n");
	for (i=0;i<3;i++){
		printf ("%d ",vr[i]);
	}

	return 0;
}

void multi(int v1[3], int v2[3], int vr[3]){
	int i;
	
	for (i=0;i<3;i++){
		vr[i]=v1[i]*v2[i];
	}
	
}
