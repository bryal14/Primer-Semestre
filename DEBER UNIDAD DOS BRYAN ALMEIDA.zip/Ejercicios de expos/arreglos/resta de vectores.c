#include <stdio.h>

void resta(int v1[2], int v2[2], int vr[2]);

int main(){
	int i;
	int v1[2]={5, 6};
	int v2[2]={1, 2};
	int vr[2];
	resta(v1,v2,vr);
	
	printf ("El vector 1 es:\n");
	for (i=0;i<2;i++){
		printf ("%d ",v1[i]);
	}
	
	printf ("\n\nEl vector 2 es:\n");
	for (i=0;i<2;i++){
		printf ("%d ",v2[i]);
	}
	
		printf ("\n\nEl resultado de la suma es:\n");
	for (i=0;i<2;i++){
		printf ("%i ",vr[i]);
	}
	
	
	return 0;
}

void resta(int v1[2], int v2[2], int vr[2]){
	int i;
	
	for(i=0;i<2;i++)
	vr[i] = v1[i]- v2[i];
	
}
