//un codigo que permita sumar vectores

#include <stdio.h>
void suma(int v1[4], int v2[4], int vr[4]);

int main(){
	int v1[4]={8,1,3,9};
	int v2[4]={5,2,4,8};
	int vr[4];
	int i;
	suma(v1, v2,vr);
	
	printf ("Vector 1 es:\n");
	for (i=0;i<4;i++){
		printf ("%d ",v1[i]);
	}
	
	printf ("\n\nVector 2 es:\n");
	for (i=0;i<4;i++){
		printf ("%d ",v2[i]);
	}
	
	printf ("\n\nLa suma delos vectores es:\n");
	for (i=0;i<4;i++){
		printf ("%d ",vr[i]);
	}
	
	return 0;
}

void suma(int v1[4], int v2[4], int vr[4]){
	int i;
	
	
	for (i=0;i<4;i++){
		vr[i]=v1[i]+v2[i];
	}
	 
	
}
