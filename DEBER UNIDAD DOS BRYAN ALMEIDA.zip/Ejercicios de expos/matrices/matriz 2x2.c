//ejercicios de impresion de matrices matriz 2x2

#include <stdio.h>

int main(){
	int matrix[2][2]={{2, 3},{4, 5}};
	int i,j;
	
	for (i=0;i<2;i++){
		for (j=0;j<2;j++){
		printf ("%d ",matrix[i][j]);	

	}

	printf ("\n");
	}
	return 0;
	
}
