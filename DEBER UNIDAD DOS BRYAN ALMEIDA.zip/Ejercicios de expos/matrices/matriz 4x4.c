//imprima una matriz 4x4 ingresando sus elementos 

#include <stdio.h>

int main(){
	int matrix[4][4]={{8, 5, 4, 7}, {9 , 2, 5, 1}, {4, 2, 6, 7}, {9, 8, 1, 3}};
	int i,j;
	
	for (i=0; i<4; i++ ) {
		for (j=0; j<4; j++){
			printf ("%d ",matrix[i][j]);
		}
	printf ("\n");
	}
	return 0;
}
