//ejercicios de resta de matrices 

//ejercicios de resta de matrices 
#include<stdio.h>
void resta(int m1[2][2],int m2[2][2],int mx[2][2]);

int main(){
     int m1[2][2]={{1, 2}, {3, 4}};
     int m2[2][2]={{1, 1}, {2, 2}};
     int mx[2][2];
     int i,j;
     
    resta(m1 ,m2 ,mx);
     
     printf("Matriz 1\n");
    for (i=0 ; i<2 ; i++){
        for(j=0; j<2;j++){
          printf("%d ", m1[i][j]);
        }
    
        printf ("\n");
    }
     printf("Matriz 2\n");
    for (i=0;i<2;i++){
        for(j=0;j<2;j++){
          printf("%d ", m2[i][j]);
        }
    
        printf ("\n");
    }
    
    
     printf ("Suma de las matrices\n");
    for (i=0; i<2; i++){
        for(j=0; j<2; j ++){
          printf("%d ", mx[i][j]);
        }
    
        printf ("\n");
    }
    return 0;
}

void resta(int m1[2][2],int m2[2][2],int mx[2][2]){
     
    int i,j;
    
    for (i=0; i<2; i++){
        for(j=0; j<2; j++){
          mx[i][j]=m1[i][j] - m2[i][j];
        }
    }
    
}
