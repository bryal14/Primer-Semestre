#include <stdio.h>
void sumarMatrices(int matriz1[2][2], int matriz2[2][2], int resultado[2][2]);
void sumarMatrices(int matriz1[2][2], int matriz2[2][2], int resultado[2][2]) {
    
	int i,j;
	for ( i = 0; i < 2; i++) {
        for (j = 0; j < 2; j++) {
            resultado[i][j] = matriz1[i][j] + matriz2[i][j];
        }
    }
}

int main() {
    int matriz1[2][2] = {{1, 2}, {3, 4}};
    int matriz2[2][2] = {{5, 6}, {7, 8}};
    int resultado[2][2];
    int i,j;

    sumarMatrices(matriz1, matriz2, resultado);

    printf("Matriz 1:\n");
    for (i = 0; i < 2; i++) {
        for (j = 0; j < 2; j++) {
            printf("%d ", matriz1[i][j]);
        }
        printf("\n");
    }

    printf("\nMatriz 2:\n");
    for (i = 0; i < 2; i++) {
        for (j = 0; j < 2; j++) {
            printf("%d ", matriz2[i][j]);
        }
        printf("\n");
    }

    printf("\nResultado de la suma:\n");
    for (i = 0; i < 2; i++) {
        for (j = 0; j < 2; j++) {
            printf("%d ", resultado[i][j]);
        }
        printf("\n");
    }

    return 0;
}
