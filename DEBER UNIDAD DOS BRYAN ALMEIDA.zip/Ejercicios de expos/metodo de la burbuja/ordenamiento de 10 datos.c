//ordenar un vector de 10 numeros con metodo de la burbuja 

#include <stdio.h>

int main(){
	int vector[10]={100,36, 6,5,11,34,54,98,1,2};
	int i,j;
	int aux;
	
	for (i=0;i<10;i++){
		for(j=0;j<10;j++){
			if (vector [j]>vector[j+1]){
				aux=vector[j+1];
				vector[j+1]=vector[j];
				vector [j]=aux;
			}
		}
	}
	printf ("El arreglo ordenado se ve asi:\n");
	for (i=0;i<10;i++){
		printf ("%d ",vector[i]);
	}
	return 0;
}
