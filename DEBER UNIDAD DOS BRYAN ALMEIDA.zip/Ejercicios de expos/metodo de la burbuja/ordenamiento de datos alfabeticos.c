#include <stdio.h>
#include <string.h>

int main() {
    char vector[3][20] = {"abc", "def", "ghi"};
    int tamano = sizeof(vector) / sizeof(vector[0]);
    int i,j;
    int temp;

    for (i = 0; i < tamano - 1; i++) {
        for (j = 0; j < tamano - i - 1; j++) {
            if (strcmp(vector[j], vector[j + 1]) > 0) {
                char temp[20];
                strcpy(temp, vector[j]);
                strcpy(vector[j], vector[j + 1]);
                strcpy(vector[j + 1], temp);
            }
        }
    }

    printf("Arreglo ordenado en orden alfabetico ascendente:\n");
    for ( i = 0; i < tamano; i++) {
        printf("%s\n", vector[i]);
    }

    return 0;
}
