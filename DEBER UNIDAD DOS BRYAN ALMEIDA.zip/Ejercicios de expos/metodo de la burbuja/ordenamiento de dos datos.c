//ordenar un vector de dos numeros con metodo de la burbuja 

#include <stdio.h>

int main(){
	int vector[2]={6,5};
	int i,j;
	int aux;
	
	for (i=0;i<2;i++){
		for(j=0;j<2;j++){
			if (vector [j]>vector[j+1]){
				aux=vector[j+1];
				vector[j+1]=vector[j];
				vector [j]=aux;
			}
		}
	}
	printf ("El arreglo ordenado se ve asi:\n");
	for (i=0;i<2;i++){
		printf ("%d ",vector[i]);
	}
	return 0;
}
