//ordenar datos ingresados por teclado



#include <stdio.h>

int main(){
	int vector[10];
	int i,j;
	int aux;
	
	

	
	printf ("Ingrese 10 numeros:\n");
	for (i=0;i<10;i++){
		i+1;
		scanf ("%d ",&vector[i]);
	}
			for (i=0;i<10;i++){
		for(j=0;j<10;j++){
			if (vector [j]>vector[j+1]){
				aux=vector[j+1];
				vector[j+1]=vector[j];
				vector [j]=aux;
			}
		}
	}

	
		printf ("Ingrese 10 numeros:\n");
	for (i=0;i<10;i++){
		printf ("%d ",vector[i]);
	}
	return 0;
}
