#include <stdio.h>

int des();

int main() {
	int result;
  result=des();
  if (result==1)
  printf ("%d",result);
    return 0;
}
int des(){
   	int  i = 10;
    while (i >= 1) {
        printf("%d ", i);
        i--;
    }
    return 1;
}
