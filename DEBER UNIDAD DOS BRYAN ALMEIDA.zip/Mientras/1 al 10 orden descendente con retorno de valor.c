#include <stdio.h>

void des();

int main() {
    des();
    return 0;
}
void des(){
        int i = 40;
    while (i >= 1) {
        printf("%d ", i);
        i--;
    }
}
