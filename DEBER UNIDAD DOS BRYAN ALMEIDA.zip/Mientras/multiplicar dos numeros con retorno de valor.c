#include <stdio.h>

int multi(int n1,int n2);

int main() {
	int result;
	int n1,n2;
    printf("Ingrese dos numeros: ");
    scanf("%d %d", &n1, &n2);
    result=multi(n1,n2);
    if(result==1)
    printf("%d", result);
    return 0;
}

int multi(int n1,int n2){

    int resultado = 0, contador = 0;
    while (contador < n2) {
        resultado += n1;
        contador++;
    }

    printf("El resultado es: %d\n", resultado);
    return 1;
}
