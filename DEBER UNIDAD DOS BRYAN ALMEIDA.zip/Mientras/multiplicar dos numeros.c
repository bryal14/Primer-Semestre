#include <stdio.h>

void multi();

int main() {
    multi();
    return 0;
}
void multi(){
        int n1, n2;
    printf("Ingrese dos numeros: ");
    scanf("%d %d", &n1, &n2);

    int resultado = 0, contador = 0;
    while (contador < n2) {
        resultado += n1;
        contador++;
    }

    printf("El resultado es: %d\n", resultado);
}
