//Imprimir los n�meros pares desde 2 hasta n, 

#include <stdio.h>
int pares(int n, int i);

int main() {
	int i,n;
	int result;
    i = 2;
    printf("Ingrese un numero: ");
    scanf("%d", &n);
    result=pares(n,i);
    if(result==1){
    	printf("%d",result);
	}
	else{
		
	}
    return 0;
}
int pares(int n, int i){
	

    while (i <= n) {
        printf("%d ", i);
        i += 2;
    }
    printf("\n");
	return 1;

}
