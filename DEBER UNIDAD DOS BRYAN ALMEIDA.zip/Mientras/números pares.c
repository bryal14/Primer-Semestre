//Imprimir los n�meros pares desde 2 hasta n, donde n es un n�mero ingresado por el usuario.
#include <stdio.h>
void pares();

int main() {
    pares();
    return 0;
}
void pares(){
	int n, i = 2;
    printf("Ingrese un numero: ");
    scanf("%d", &n);

    while (i <= n) {
    	printf("Los numeros pares son\n");
        printf("%d ",i);
        i += 2;
    }

    printf("\n");
}
