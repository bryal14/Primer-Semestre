//salir para finalizar con retorno de datos 
#include <stdio.h>
#include <string.h>

int salir(char nombre[50]);

int main() {
    int print,nombre[50];
    print=salir(nombre[50]);
    if (print==2){
    	printf ("%d",print);
	}
    return 0;
}
int salir(char nombre[50]){

    while (1) {
        printf("Ingrese su nombre (escriba 'salir' para terminar): ");
        scanf("%s", nombre);
        if (strcmp(nombre, "salir") == 0) {
            break;
        }
        printf("%s", nombre);
    }
    printf("�Hasta luego!\n");
    
    return 2;
}
