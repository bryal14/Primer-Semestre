//salir para finalizar
#include <stdio.h>
#include <string.h>
void salir();
int main() {
salir ();
    return 0;
}

void salir(){
	    char nombre[50];
    while (1) {
        printf("Ingrese su nombre (escriba 'salir' para terminar): ");
        scanf("%s", nombre);
        if (strcmp(nombre, "salir") == 0) {
            break;
        }
        printf("�Hola, %s!\n", nombre);
    }
    printf("�Hasta luego!\n");
}
