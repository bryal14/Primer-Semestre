//Imprimir la tabla de multiplicar de un n�mero ingresado por teclado.

#include <stdio.h>
int tabla(num);

int main() {
	int i = 1;
	int num;
	int result;
	
    puts("Ingrese un n�mero: ");
    scanf("%d", &num);
    result=tabla(num);
    if (result==1)
    printf("%i",result);
    
    return 0;
}

int tabla(int num){
	int i=1;
	

    while (i <= 20) {
        printf("%d * %d = %d\n", num, i, num * i);
        i++;
    }
	return 1;
}
