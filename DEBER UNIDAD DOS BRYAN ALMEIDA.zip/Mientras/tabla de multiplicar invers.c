#include <stdio.h>
void tabla();

int main() {

    tabla();

    return 0;
}

void tabla(){
      int num, i = 20;
    printf("Ingrese un numero: ");
    scanf("%d", &num);

    printf("Tabla de multiplicar de %d en orden descendente:\n", num);
    while (i >= 1) {
        printf("%d * %d = %d\n", num, i, num * i);
        i--;  }
}
