#include <stdio.h>
int tabla(int num);

int main() {
    int num,result;
    printf("Ingrese un numero: ");
    scanf("%d",&num);
    result=tabla(num);
    if (result==1)
    printf ("%d",result);

    return 0;
}

int tabla(int num){
      int i;
      i = 20;
    printf("Tabla de multiplicar de %d en orden descendente:\n", num);
    while (i >= 1) {
        printf("%d * %d = %d\n", num, i, num * i);
        i--;  }
        return 1;
}
