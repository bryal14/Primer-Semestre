//Imprimir la tabla de multiplicar de un n�mero ingresado por teclado.

#include <stdio.h>
void tabla ();

int main() {
    tabla();
    return 0;
}

void tabla(){
	int num, i = 1;
	
    puts("Ingrese un n�mero: ");
    scanf("%d", &num);

    while (i <= 20) {
        printf("%d * %d = %d\n", num, i, num * i);
        i++;
    }

}
