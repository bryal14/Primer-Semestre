//mayor residuo de dos numeors con retorno de datos
#include <stdio.h>

int mayor_menor(int n1,int n2);


int main(){
	int result,n1,n2;
	printf ("Ingrese dos numeros a ser comparados\n: ");
	scanf ("%d",&n1);
	scanf ("%d",&n2);
	result=mayor_menor(n1,n2);
	if (result==1){
		printf ("El numero %d es mayor:",n1);
	}
	else {
	printf ("El numero %d es mayor:",n2);	
	}
	return 0;
}

int mayor_menor(int n1,int n2){
	

	if (n1>n2){
	
	return 1;
}
	else {
	
	}
	return 0;
}


