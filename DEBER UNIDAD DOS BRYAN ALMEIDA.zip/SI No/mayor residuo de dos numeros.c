//determinar el mayor de dos numeros 

#include <stdio.h>
void mayor_menor();
int main(){
	mayor_menor();
	return 0;
}

void mayor_menor(){
	int n1,n2;
	
	printf ("Ingrese dos numeros a ser comparados\n: ");
	scanf ("%d",&n1);
	scanf ("%d",&n2);
	if (n1>n2){
	printf ("El numero %d es mayor:",n1);
}
	else {
	printf ("El numero %d es mayor:",n2);
	}
}


