//paga de horas extras con retorno de datos 
#include<stdio.h>
int paga(int horas,int horas_extra);

int main(){
	int result;
	int salario,horas_extra,horas;
	printf ("Ingrese el numero de horas trabajadas: ");
	scanf ("%i",&horas);
	printf ("Ingrese el numero de horas extras: ");
	scanf ("%i",&salario);
	result=paga(horas,horas_extra);
	if (result==1){
	printf ("Su salario sera de:%i",240);
	}
	else{
	printf("Su salario sera:%i",horas_extra);
	}
	return 0;
}

int paga(int horas,int horas_extra){
	
	if (horas<=40){
return 1;
}
	if  (horas>40){
	horas_extra= 240+(15*240);
	}
	return 0;	
}
