//paga horas extras 

#include<stdio.h>

void paga();

int main(){
	paga();
	return 0;
}

void paga(){
	int salario,horas_extra,horas;
	printf ("Ingrese el numero de horas trabajadas: ");
	scanf ("%i",&horas);
	printf ("Ingrese el numero de horas extras: ");
	scanf ("%i",&salario);
	if (horas<=40){
	printf ("Su salario sera de:%i",240);
}
	if  (horas>40){
	horas_extra= 240+(15*240);
	printf("Su salario sera:%i",horas_extra);
	}	
}
