//pago de productos con retorno de datos 
#include<stdio.h>

int pago(int n1);

int main(){
	int n1;
	int result;
	printf ("\nIngrese el monto a ser pagado\n");
	printf ("\nDe ser mayor a 100 dolares pagara en tarjeta\n");
	printf ("De ser menor a 100 dolares pagara en efectivo\n\n");
	scanf("%d",&n1);
	result=pago(n1);
	if (result==0){
	printf("\n\nSu pago es de %d y debe hacerce en efectivo",n1);
	}
	else{
	printf ("\n\nSu pago es de %d y debe hacerce en tarjeta ya sea credito o debito",n1);	
	}
	return 0;
}

int pago(int n1){
	
	if (n1<=100){
		return 0;
	}
	
	else {
		return 1;
	}
	
}
