// programa que indique el metodo de pago segun el valor a pagar

#include<stdio.h>

void pago();

int main(){
	pago();
	return 0;
}

void pago(){
	int n1;
	printf ("\nIngrese el monto a ser pagado\n");
	printf ("\nDe ser mayor a 100 dolares pagara en tarjeta\n");
	printf ("De ser menor a 100 dolares pagara en efectivo\n\n");
	scanf("%d",&n1);
	if (n1<=100)
	printf("\n\nSu pago es de %d y debe hacerce en efectivo",n1);
	else 
	printf ("\n\nSu pago es de %d y debe hacerce en tarjeta ya sea credito o debito",n1);
}
