//ingrese por teclado el dos numeros y compare cual es mayor y cual es menor 

#include <stdio.h>
void mayor ();

int main(){
	mayor ();
	return 0;
}
void mayor(){
	int n1,n2;
	printf ("Ingrese dos numeros para que estos sean comparados:\n\n");
	scanf("%d %d",&n1,&n2);
	if (n1>n2)
	printf ("El numero %d es mayor",n1);
	else
	printf ("El numero %d es mayor",n2);
}


