//valor mayor con retorno
#include <stdio.h>
int mayor(int n1,int n2);

int main(){
	int n1,n2;
	int result;
	printf ("Ingrese dos numeros para que estos sean comparados:\n\n");
	scanf("%d %d",&n1,&n2);
	result=mayor(n1,n2);
	if (result==20){
	printf ("El numero %d es mayor",n1);	
	}
	else{
	printf ("El numero %d es mayor",n2);	
	}
	return 0;
}
int mayor(int n1,int n2){
	
	if (n1>n2){
	return 20;	
	}
	
	else{
	return 0;
	}

}

 
