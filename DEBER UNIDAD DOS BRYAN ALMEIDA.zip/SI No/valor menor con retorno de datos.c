//valor menor con retorno de datos
#include <stdio.h>

int menor (int n1,int n2);

int main(){
	int n1,n2;
	int result;
	printf("Ingrese dos numeros a ser comparados: ");
	scanf("%d %d",&n1,&n2);
	result=menor(n1,n2);
	if (result==0){
	printf ("El numero %d es menor ",n1);	}

	else {
	printf ("El numero %d es menor ",n2);}
	
	return 0;
}
int menor(int n1,int n2){

	
	if (n1<n2){
	return 0;}
	
	else {
	return 1;}
	
}
