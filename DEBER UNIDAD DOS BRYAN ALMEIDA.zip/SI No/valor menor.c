//ingrese por teclado y muestre por pantalla dos numeros e indique cual es el mayor y cual es el menor 

#include <stdio.h>

void menor ();

int main(){
	menor ();
	return 0;
}
void menor(){

	int n1,n2;
	printf("Ingrese dos numeros a ser comparados: ");
	scanf("%d %d",&n1,&n2);
	if (n1<n2)
	printf ("El numero %d es menor ",n1);
	else 
	printf ("El numero %d es menor ",n2);
	
	
}
