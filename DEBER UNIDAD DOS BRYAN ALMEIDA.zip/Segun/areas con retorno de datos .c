//areas con retorno de datos 

#include <stdio.h>

int cuadrado(int l);
int rectangulo(int b,int h);
int triangulo(int b,int h);



int main(){
	int opcion,result,b,h,l; 
	

printf ("Presione (1) para calcular el area de un cuadrado\n");
printf ("Presione (2) para calcular el area de un rectangulo\n");
printf ("Presione (3) para calcular el area de un triangulo\n");
printf ("Presione (4) para salir del programa\n\n");
scanf ("%d",&opcion);


switch (opcion){

case 1:
	printf("Ingrese un lado del cuadrado: ");
	scanf ("%d",&l);
	result=cuadrado(l);
	printf ("El area del cuadrado es: %d\n",result);
 
break;
	

case 2:
    printf("Ingrese la base y la altura del rectangulo: ");
	scanf ("%d %d",&b,&h);
	result=rectangulo(b,h);
	printf ("El area del rectangulo es: %d\n",result); 
break;

case 3:
  	printf("Ingrese la base y la altura del triangulo: ");
	scanf ("%d %d",&b,&h);
	result=triangulo(b,h);
	printf ("El area del triangulo es: %d\n",result);
break;

case 4:
printf("\n\nUsted salio exitosamente del programa, gracias por preferirnos");
break;

default:
 printf("\n\nValor invalido\n\n");
break;   
}
    return 0;
    }
    



int cuadrado(int l){
    int result;

result=l*l;
	return result;
}


int rectangulo(int b,int h){
    
    int  result;
result=b*h;
	return result;
}

int triangulo(int b,int h){
    int result;
result=(b*h)/2;
	return result;
}
