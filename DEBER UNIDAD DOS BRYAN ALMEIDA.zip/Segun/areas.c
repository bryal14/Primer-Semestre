//un algoritmo que nos permita calcular diferentes areas y realizar distintas operaciones desde un menu de opciones

#include <stdio.h>

void cuadrado();
void menu();
void rectangulo();
void triangulo();



int main(){

menu();




    return 0;
    }
    
void menu(){
   int opcion; 

printf ("Presione (1) para calcular el area de un cuadrado\n");
printf ("Presione (2) para calcular el area de un rectangulo\n");
printf ("Presione (3) para calcular el area de un triangulo\n");
printf ("Presione (4) para salir del programa\n\n");
scanf ("%d",&opcion);


switch (opcion){

case 1:
cuadrado();
break;


case 2:
rectangulo();
break;

case 3:
triangulo ();
break;

case 4:
printf("\n\nUsted salio exitosamente del programa, gracias por preferirnos");
break;

default:
 printf("\n\nValor invalido\n\n");
break;
}


    
}

void cuadrado(){
    int l, result;
    printf("Ingrese un lado del cuadrado: ");
scanf ("%d",&l);
result=l*l;
printf ("El area del cuadrado es: %d\n",result);
}
void rectangulo(){
    
    int b,h, result;
  printf("Ingrese la base y la altura del rectangulo: ");
scanf ("%d %d",&b,&h);
result=b*h;
printf ("El area del rectangulo es: %d\n",result);  
}

void triangulo(){
    int b,h, result;
  printf("Ingrese la base y la altura del triangulo: ");
scanf ("%d %d",&b,&h);
result=(b*h)/2;
printf ("El area del triangulo es: %d\n ",result);
}
