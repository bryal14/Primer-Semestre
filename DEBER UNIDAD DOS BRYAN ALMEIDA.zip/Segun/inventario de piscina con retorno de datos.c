//codigo que me permita saber que implementos hay en el inventario de una piscina 

#include<stdio.h>

int menu(int opcion);
void implementos();
void salir();


int main(){
	int m=1,opcion;
	printf("Presione 1 para consultar productos: ");
	printf("Presione 0 para salir del inventario: ");
	m=menu(opcion);
	
	return 0;
}

int menu(int opcion){
	
	int m;
	
	
	scanf("%i",&opcion);
	
	switch(opcion){
	case 1: 
	implementos();
			break;
	case 2:
		salir();
			break;
	default: puts("seccion inexistente");
	
	}
	puts("final del programa");
	m=menu(opcion);
	return m;
}

void implementos(){
	puts("Disponemos de tablas||aletas||paletas y dos snorkels");
}

void salir(){
	puts("Usted ha salido exitosamente del inventario");
}
//inventario de piscina con retorno de datos
