//codigo que me permita saber que implementos hay en el inventario de una piscina 

#include<stdio.h>

void menu();
void implementos();
void salir();


int main(){
	 menu();
	return 0;
}

void menu(){
	
	int opcion;
	
	printf("Presione 1 para consultar productos: ");
	printf("Presione 0 para salir del inventario: ");
	scanf("%i",&opcion);
	
	switch(opcion){
	case 1: 
	implementos();
			break;
	case 2:
		salir();
			break;
	default: puts("seccion inexistente");
	
	}
	puts("final del programa");
}

void implementos(){
	puts("Disponemos de tablas||aletas||paletas y dos snorkels");
}

void salir(){
	puts("Usted ha salido exitosamente del inventario");
}

