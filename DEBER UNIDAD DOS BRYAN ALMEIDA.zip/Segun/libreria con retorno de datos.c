//inventario de libreria con retorno de datos

//un codigo o algoritmo que nos permita conocer el repositorio de una bibioteca
#include <stdio.h>

int libros(int opcion);
void mu();
void arte ();
void biologia();
void calculo();

int main(){
	int m=0,opcion;
	puts("\nPresione 1 para libros de musica:\n ");
	puts("\nPresione 2 para libros de arte: \n");
	puts("\nPresione 3 para libros de biologia:\n ");
	puts("\nPresione 4 para libros de calculo:\n ");
	puts("\nPresione 0 para salir: ");	
	m=libros(opcion);
	printf ("%i",m);
	return 0;	
}

int libros(int opcion){

	int M;
	scanf("%i",&opcion);
	
	switch(opcion){
	case 1: 
	
	mu();
	break;
	
	case 2:
	arte();	
	break;
	case 3:
	biologia();	
	break;
	case 4:
	calculo();	
	break;		
	default: printf("\n\nseccion inexistente\n\n");
	}
	M=0;
	return M;
}

void mu(){
	puts ("\n\nElvis, la Construccion del Mito|| �ltimo Tren a Memphis|| La venganza de las punks CONTRA\n\n");
		
}

void arte(){
	puts("\n\nHISTORIA IRREVERENTE DEL ARTE|| MEMORIAS DE UN LUTHIER\n\n");
}

void biologia(){
	puts("\n\nLibros de Bacteriolog�a||Libros de Biolog�a Ambiental||Libros de Biolog�a Animal\n\n");
}

void calculo(){
	puts("\n\nC�lculo de James Stewart||C�lculo de Louis Leithold||C�lculo de Tom Apostol||Vol 1 y 2\n\n ");
}
