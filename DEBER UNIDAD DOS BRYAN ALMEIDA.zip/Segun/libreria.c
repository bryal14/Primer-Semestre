//un codigo o algoritmo que nos permita conocer el repositorio de una bibioteca
#include <stdio.h>
#include<stdlib.h>

void libros();
void mu();
void arte ();
void biologia();
void calculo();

int main(){
libros();

	return 0;	
}

void libros(){

	int opcion;
	do{
	
	printf("\nPresione 1 para libros de musica:\n ");
	printf("\nPresione 2 para libros de arte: \n");
	printf("\nPresione 3 para libros de biologia:\n ");
	printf("\nPresione 4 para libros de calculo:\n ");
	printf("\nPresione 0 para salir: ");
	scanf("%i",&opcion);
	
	switch(opcion){
	case 1: 
	
	mu();
	break;
	
	case 2:
	arte();	
	break;
	case 3:
	biologia();	
	break;
	case 4:
	calculo();	
	break;		
	default: printf("\n\nseccion inexistente\n\n");
	}
}while(opcion!=0);
}

void mu(){
	printf ("\n\nElvis, la Construccion del Mito|| �ltimo Tren a Memphis|| La venganza de las punks CONTRA\n\n");
		
}

void arte(){
	printf("\n\nHISTORIA IRREVERENTE DEL ARTE|| MEMORIAS DE UN LUTHIER\n\n");
}

void biologia(){
	printf("\n\nLibros de Bacteriolog�a||Libros de Biolog�a Ambiental||Libros de Biolog�a Animal\n\n");
}

void calculo(){
	printf("\n\nC�lculo de James Stewart||C�lculo de Louis Leithold||C�lculo de Tom Apostol||Vol 1 y 2\n\n ");
}

