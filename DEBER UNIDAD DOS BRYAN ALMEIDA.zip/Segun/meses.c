//este c�digo nos permite ver el nombre del mes con tan solo ingresar el numero respetivo al mes.
#include <stdio.h>

void menu ();
void enero();
void feb();
void mars();
void abr();
void mayo();
void juni();
void juli();
void agost();
void sep();
void oct();
void nov();
void dic();

int main(){
	menu();
	return 0;		
}
void menu (){
		int mes;
	
	printf("Escribe el mes del cual desea saber el nombre: ");
	scanf("%i",&mes);
	
	switch(mes){
	case 1: 
	enero();
			break;
	case 2:
		feb();
			break;
	case 3:
		mars();
			break;
	case 4:
		abr();
			break;
	case 5:
		mayo();
			break;
	case 6:
		juni();
			break;
	case 7:
		juli();
			break;
	case 8:
		agost();
			break;
	case 9:
		sep();
			break;
	case 10:
		oct();
			break;
	case 11:
		nov();
			break;
	case 12:
		dic();
			break;
	default: puts("mes inexistente");
	
	}
	puts("final del programa");
}
void enero(){
	puts("Enero");
}
void feb(){
	puts("Febrero");
}
void mars(){
	puts("Marzo");
}
void abr(){
	puts("Abril");
}
void mayo(){
	puts("Mayo");
}
void juni(){
	puts("Junio");
}
void juli(){
	puts("Julio");
}
void  agost(){
	puts("Agosto");
}
void sep(){
	puts("Septiembre");
}
void oct(){
	puts("Octubre");
}
void nov(){
	puts("Noviembre");
}
void dic(){
	puts("Diciembre");
}

