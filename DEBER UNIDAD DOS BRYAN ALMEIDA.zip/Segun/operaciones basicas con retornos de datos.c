//operaciones basicas con retornos de datos
#include<stdio.h>

int menu(int n1,int n2);


int main(){
	int op=0,n1,n2;
	printf ("************************************UNIVERSIDAD DE LAS FUERZAS ARMADAS****************************************\n");
	printf ("Bryan Almeida\n");
	
	printf ("FUNDAMENTOS DE PROGRAMACION \n");
	
	printf ("CALCULADORA DE OPERACIONES\n\n");
	
	op=menu(n1,n2);
	printf("%i",op);
	
	return 0;		
}

int menu(int n1,int n2){
	int op=0,opcion;
	int result1,result2,result3,result4;
	
	printf("(1) Para sumar\n");
	printf("(2) Para restar\n");
	printf("(3) Para multiplicar\n");
	printf("(4) Para dividir \n");
	printf("(5) Para salir\n");
	scanf ("%d",&opcion);
	
		
	switch (opcion){
	case 1:
	
	
	printf("Ingrese dos numeros para realizar la suma: ");
	scanf ("%d %d",&n1,&n2);
	
	result1=n1+n2;
	printf("Elresultado de la suma es:%d\n\n ",result1); 
		break;
		
	case 2:
	
	printf("Ingrese dos numeros para realizar la resta: ");
	scanf ("%d %d",n1,n2);
	
	result2=n1-n2;
	printf("Elresultado de la resta es:%d \n\n ",result2);
		break;
		
	case 3:

	
	printf("Ingrese dos numeros para realizar la multiplicacion: ");
	scanf ("%d %d",n1,n2);
	op=0;
	op=menu;
	return op;
}
}
