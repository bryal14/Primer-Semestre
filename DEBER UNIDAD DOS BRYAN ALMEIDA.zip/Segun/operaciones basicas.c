//crear un codigo que me permita elegir operaciones basicas y a su vez realizar operaciones en ellas 

#include <stdio.h>

void menu();
void suma();
void resta();
void multiplicacion();
void division();


int main(){
	printf ("************************************UNIVERSIDAD DE LAS FUERZAS ARMADAS****************************************\n");
	printf ("Bryan Almeida\n");
	
	printf ("FUNDAMENTOS DE PROGRAMACION \n");
	
	printf ("CALCULADORA DE OPERACIONES\n\n");
	
	menu();
	
	return 0;		
}

void menu(){
	int opcion;

	
do {
	printf("(1) Para sumar\n");
	printf("(2) Para restar\n");
	printf("(3) Para multiplicar\n");
	printf("(4) Para dividir \n");
	printf("(5) Para salir\n");
	scanf ("%d",&opcion);
	
	
	switch (opcion){
	case 1:
	suma();
		break;
		
	case 2:
		
	resta();
		break;
		
	case 3:
	multiplicacion();
		break;
		
		
	case 4:
	division();
		break;
		
	case 5:
		printf("Usted ha salido correctamente del programa\n");
		printf("Gracias por preferirinos\n\n");
		break;
		
	default :
		printf("opcion invalida");
		break;
}
	}while(opcion != 5);
	
	
}
void suma(){
	int result1;
	int n1,n2;
	
	printf("Ingrese dos numeros para realizar la suma: ");
	scanf ("%d %d",&n1,&n2);
	
	result1=n1+n2;
	printf("Elresultado de la suma es:%d\n\n ",result1); 
}
void resta(){
	int result2;
	int n1,n2;
	
	printf("Ingrese dos numeros para realizar la resta: ");
	scanf ("%d %d",&n1,&n2);
	
	result2=n1-n2;
	printf("Elresultado de la resta es:%d \n\n ",result2);
}
void multiplicacion(){
	int result3;
	int n1,n2;
	
	printf("Ingrese dos numeros para realizar la multiplicacion: ");
	scanf ("%d %d",&n1,&n2);
	
	result3=n1*n2;
	printf("Elresultado de la multiplicacion es:%d\n\n ",result3);
}
void division(){
	int result4;
	int n1,n2;
	
	printf("Ingrese dos numeros para realizar la division\n");
		printf("\nrecuerde que el dividir para 0 no puede ser realizado:");
		scanf ("%d %d",&n1,&n2);
		
		result4=n1/n2;
		printf("Elresultado de la division es:%d \n\n ",result4);
}

