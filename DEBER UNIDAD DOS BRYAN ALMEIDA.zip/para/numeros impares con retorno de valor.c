//encontrar los numeros impares con un bucle for 
#include<stdio.h>
int par_impar(int n1,int i);

int main(){
	int n1,i;
	int result;
	printf ("Ingrese dos numeros y se mostrara cual es par y cual es impar\n");
	scanf ("%d",&n1);
	result=par_impar(n1,i);
	if(result==1){
	printf("\nEl numero %d es par",n1);}
	else{
	printf("\nEl numero %d es impar",n1);	}
	return 0;
}

int par_impar(int n1,int i){
	
	for (i=1; i<=1; i++){
	if (n1%2==0){
	 return 1;
	}
	else{
	 return 0;
	}
	}
}
