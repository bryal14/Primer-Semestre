#include <stdio.h>

void impares();

int main(){


	impares();
	
	return 0;
}

void impares(){
	int n1, n2, i;
	
	printf ("Ingrese los numeros impares a ser reconocidos\n: ");
	scanf ("%d",&n1);
	for ( i = n1; i<=1; i++)
	if (i %2 == 1);
	printf ("Los numeros impares son: %d",i);

}
