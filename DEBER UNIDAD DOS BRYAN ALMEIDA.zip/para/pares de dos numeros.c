//imprimir usando el bucle for que numero es par o impar 

#include<stdio.h>
void par_impar();
int main(){
	par_impar();
	return 0;
}

void par_impar(){
	int n1,i;
	printf ("Ingrese dos numeros y se mostrara cual es par y cual es impar\n");
	scanf ("%d",&n1);
	for (i=1; i<=1; i++){
	if (n1%2==0){
	printf("\nEl numero %d es par",n1); 
	}else{
	printf("\nEl numero %d es impar",n1); 
	
	}

	}
}
