//imprimir latabla del 10 con funciones y retornos de valor 
#include<stdio.h>
int tabla(int n1,int i);

int main(){
int n1,i;
int result;
	n1=10;
	printf ("*****************************tabla del 10*****************************");
	result=tabla(n1,i);
	if(result==1){
		printf ("%i",result);
	}
	return 0;
}

int tabla(int n1,int i){
	
	for(i=1;i<=10;i++){
	printf("\n%d*%d=*%d",n1,i,n1*i);
	return 1;
}
}
