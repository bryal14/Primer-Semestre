//imprima la tabla del 10

#include <stdio.h>

void tabla();

int main(){
	
	tabla ();

	return 0;
}

void tabla(){
	int n1,i;
	n1=10;
	printf ("*****************************tabla del 10*****************************");
	for(i=1;i<=10;i++){
	printf("\n%d*%d=*%d",n1,i,n1*i);
}
}
