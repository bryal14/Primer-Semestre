//imprimir la tabla de un numero que sea de manera inversa mediante un bucle for 
#include <stdio.h>

int tabla(int n1,int i);

int main(){
 	int i,n1;
 	int result;
 	n1=5;
	printf("Ingrese el numero del cual desea la tabla inversa\n:");
	scanf("%d",&n1);
	result=tabla(n1,i);
	if (result==9){
		printf("%d",result);
	}
	return 0;	
}


int tabla(int n1,int i){

	for ( i =10;i <= 1; i--){
	printf ("\n %d * %d=%d", n1,i, n1*i);
}
	return 9;
}
