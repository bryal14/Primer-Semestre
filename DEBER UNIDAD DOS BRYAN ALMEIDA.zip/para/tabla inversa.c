//prueba de archivos y codigos 
#include <stdio.h>

void tabla();

int main(){
 	
	tabla();

	return 0;	
}


void tabla(){
	int n1,i;
	printf("Ingrese el numero del cual desea la tabla inversa\n:");
	scanf("%d",&n1);
	for ( i =10;i>= 1; i--){
	printf ("\n %d * %d=%d", n1,i, n1*i);
}
}

	
