#include <stdio.h>

void adivina();

int main() {
    
    adivina();
    return 0;
}
void adivina(){
    int dia_secreto = 19;
    int mes_secreto = 06;

    int dia, mes;
    
    printf("Adivina el dia y el mes secreto (formato DD MM).\n");
    printf("Una pista seria las festividades de la ESPE.\n");
    while (1) {
        printf("Ingrese el dia: ");
        scanf("%d", &dia);
        printf("Ingrese el mes: ");
        scanf("%d", &mes);

        if (dia == dia_secreto && mes == mes_secreto) {
            printf("�tu respuesta es correcta!: %d %d.\n", dia_secreto, mes_secreto);
            break;
        } else {
            printf("No es la fecha correcta. �Intenta nuevamente!\n");
        }
    }
}
