#include <stdio.h>

int adivina(dia,mes);

int main() {
     int result;
     int dia,mes;
    printf("Adivina el d�a y el mes secreto (formato DD MM).\n");
    printf("Una pista seria las festividades de la ESPE.\n");
    result=adivina(dia,mes);
    if (result==1){
    printf ("%d",result);
	}
    return 0;
}
int adivina(int dia,int mes){
    int dia_secreto = 19;
    int mes_secreto = 06;
  
    while (1) {
        printf("Ingrese el dia: ");
        scanf("%d", &dia);
        printf("Ingrese el mes: ");
        scanf("%d", &mes);

        if (dia == dia_secreto && mes == mes_secreto) {
            printf("�tu respuesta es correcta!: %d %d.\n", dia_secreto, mes_secreto);
            break;
        } else {
            printf("No es la fecha correcta. �Intenta nuevamente!\n");
        }
    }
    return 1;
}
