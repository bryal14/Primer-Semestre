//ingresa contrase�a con retorno de datos
//adivina la contrase�a

#include<stdio.h>

int  clave(int intento);

int main() {
	int result,intento;
	char usuario[50];
    
    printf("Ingrese su nombre de usuario: ");
    scanf("%s", usuario);
	result=clave(intento);
	if (result==1){
		printf ("%d",result);
	}
    return 0;
}

int clave(int intento){
	int contrasena = 2010;
	char usuario[50];
    while (1) {
        printf("Ingrese la contrase�a: ");
        scanf("%d", &intento);

        if (intento == contrasena) {
            printf("Ha ingresado correctamente", usuario);
            break;
        } else {
            printf("Contrase�a incorrecta.Intenta nuevamente\n");
        }
    }
    return 1;
}
