//adivina la contrase�a

#include <stdio.h>

void clave();

int main() {
	clave();
    return 0;
}

void clave(){
	    char usuario[50];
    int contrasena = 2010;
    int intento;

    printf("Ingrese su nombre de usuario: ");
    scanf("%s", usuario);

    while (1) {
        printf("Ingrese la contrase�a: ");
        scanf("%d", &intento);

        if (intento == contrasena) {
            printf("Ha ingresado correctamente", usuario);
            break;
        } else {
            printf("Contrase�a incorrecta.Intenta nuevamente\n");
        }
    }
}
