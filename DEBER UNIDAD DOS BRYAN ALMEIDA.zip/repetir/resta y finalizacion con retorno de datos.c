//suma de numeros hasta que el usuario lo desee

#include <stdio.h>

int rest(int resta);

int main (){
	int result;
	int resta;
	result=rest(resta);
	if (result=1){
	printf ("%d",result);	}

	return 0;
}

int rest(int resta){	
	int n1,n2;
	
	do{
		
	printf ("Presione el (0) dos veces para finalizar el programa\n");
	printf ("\nIngrese los numeros a sumarse\n");
	scanf("%d %d",&n1,&n2);
	resta=n1-n2;
	printf ("\nEl resultado de la suma es %d\n",resta);
	
	}while(resta!=0);
	return 1;
}
