//resta y finalizacion 
#include <stdio.h>

void restar();

int main (){
	restar();
	return 0;
}

void restar(){
	int n1,n2;
	int restar;
	
	do{
	printf ("Presione el (0) dos veces para finalizar el programa\n");
	printf ("\nIngrese los numeros a sumarse\n");
	scanf("%d %d",&n1,&n2);
	restar=n1-n2;
	printf ("\nEl resultado de la suma es %d\n",restar);
	}while(restar!=0);
}
