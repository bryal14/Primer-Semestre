//suma de numeros hasta que el usuario lo desee

#include <stdio.h>

int suma(int sumar);

int main (){
	int result;
	int sumar;
	result=suma(sumar);
	if (result=1){
	printf ("%d",result);	}

	return 0;
}

int suma(int sumar){	
	int n1,n2;
	
	do{
		
	printf ("Presione el (0) dos veces para finalizar el programa\n");
	printf ("\nIngrese los numeros a sumarse\n");
	scanf("%d %d",&n1,&n2);
	sumar=n1+n2;
	printf ("\nEl resultado de la suma es %d\n",sumar);
	
	}while(sumar!=0);
	return 1;
}
