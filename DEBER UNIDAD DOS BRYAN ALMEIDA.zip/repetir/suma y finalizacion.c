//suma de numeros hasta que el usuario lo desee

#include <stdio.h>

void suma();

int main (){
	suma();
	return 0;
}

void suma(){
	int n1,n2;
	int suma;
	
	do{
	printf ("Presione el (0) dos veces para finalizar el programa\n");
	printf ("\nIngrese los numeros a sumarse\n");
	scanf("%d %d",&n1,&n2);
	suma=n1+n2;
	printf ("\nEl resultado de la suma es %d\n",suma);
	}while(suma!=0);
}
