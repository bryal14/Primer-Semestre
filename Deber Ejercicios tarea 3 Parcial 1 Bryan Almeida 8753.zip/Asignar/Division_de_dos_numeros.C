//un codigo que nos permita la division de dos n�meros ingresados por teclado y mostrar su resultado en pantalla
//creacion de un codigo que nos permita realizar divisiones y mostrar el resultado por pantalla
#include <stdio.h>//incluimos las librerias que nos permitan la entrada y la salida de datos 
#include <math.h>//inlcluimos las librerias que nos permiten la realizacion de operaciones matematicas

int main(){
	float resultado;//aqui definimos la primera variable como decimal o flotante aqui se almacenar� el resultado
	float dividendo; //aqui definimos la segunda variable como flotante y se almacenar� el dividendo
	float divisor;//aqui definimos la tercera variable como flotante y se almacenara el divisor 
	printf ("Ingrese el dividendo: ");//aqui le pedimos al usuario que ingrese el numero a dividir
	scanf ("%f",&dividendo);//aqui leemos la segunda variable 
	printf ("Ingrese el divisor: ");//aqui pedimos al usuario que indique el n�mero a ser dividido
	scanf ("%f",&divisor);//aqui leemos la tercera variable 
	resultado = dividendo / divisor;//aqui almacenamos el resultado de la operacion en la primera variable 
	printf("El cociente es:%f",resultado);//aqui mostramos por pantalla el resultado de la operacion realizada
	return 0;	
}
