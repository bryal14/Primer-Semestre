//Crear un c�digo que nos permita multiplicar dos n�meros
//un codigo que nos permita multiplicar dos n�meros ingresados por teclado y mostrar su resultado en pantalla
#include<stdio.h>//incluimos la libreria que nos va a permitir la entrada y la salida de datos
#include<math.h>//incluimos la libreria que nos va a permitir la realizacion d operaciones matem�ticas

int main(){
	int num1;//definimos la primera variable como entero y aqui se almacenar� el primer n�mero
	int num2;//definimos la segunda variable como entero y aqui se almacenar� el segundo n�mero
	int resultado;//definimos la tercera variable como entero y aqui se almacenar� e� resultado de la operacion

	printf ("Ingrese el primer numero: ");//aqui le pedimos al usuario que ingrese el primer n�mero
	scanf ("%i",&num1);//aqui leemos la primera variable definida 
	printf ("Ingrese el segundo numero: ");//aqui le pedimos al usuario que ingrese el segundo n�mero
	scanf ("%i",&num2);//aqui leemos la segunda variable
	resultado=num1*num2;//aqui almacenamos la operacion matematica en la tercera variable o variable resultado
	printf("El resultado de la multiplicacion es:%d",resultado);//mostramos por pantalla la respuesta a la operacion matematica
	return 0;
	}
