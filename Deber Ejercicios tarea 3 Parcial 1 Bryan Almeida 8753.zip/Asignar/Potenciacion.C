//potenciar un n�mero ingresando su base y su exponente por teclado y mostrar su resultado en pantalla
#include<stdio.h>//incluimos la libreria a ser utilizada para la entrada y salida de datos
#include<math.h>//incluimos la libreria que nos va a permitir el realizar operaciones matematicas

int main(){
	int base;//definimos la primera variable como entera y aqui se va a almacenar la base de la operacion
	int exponente;//definimos la segunda variable como entera y aqui se va a almacenar el exponente de la operacion
	int resultado;//definimos la tercera variable como entera y aqui se va a almacenar el resultado de la operacion
	printf("Ingrese la base: ");//Le pedimos al usuario que ingrese un n�mero
	scanf("%i",&base);//leemos la primera variable 
	printf ("Ingrese el exponente: ");//le pedimos al usuario que ingrese un segundo n�mero
	scanf ("%i",&exponente);//leemos la segunda variable
	resultado=pow(base, exponente);//almacenamos en la tercera variable el resultado de la operacion
	printf ("El resultado de la potenciacion es: %i",resultado);//mostramos por pantalla el resultado de la operacion
	return 0;
}
