//un c�digo que nos permite restar dos n�meros ingresados por teclado 

#include<stdio.h>//Incuimos las librerias para poder definir datos
#include<math.h>//Incluimos la libreria que nos va a permitir realizar operaciones matem�ticas

int main(){
	int num1; //definimos la primera variable como entera y aqui se almacenar� el primer n�mero
	int num2;//definimos la segunda variable como entera y aquis e alacenar� el segundo n�mero
	int resultado;//en esta variable almacenaremos el resultado de la operacion 
	printf ("Ingrese el primer numero: ");//le pedimos al usuario que ingrese el primer n�mero
	scanf ("%i",&num1);//leemos la primera variabe definida
	printf ("Ingrese el segundo numero: ");//le pedimos al usiario que ingrese el segundo n�mero
	scanf ("%i",&num2);//leemos la seegunda variable definida
	resultado=num1-num2;//realizamos la opreacion y almacenamos el resultado en la segunda variable
	printf ("El resultado de la resta es:%d",resultado);//mostramos por pantalla el resultado de la opreacion 
	
	return 0;
}
