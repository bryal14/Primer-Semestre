//crear un algoritmo que permita sumar dos numeros ingresados por teclado

#include<stdio.h> //Incluimos las librer�as en este caso para entrada y salida de datos
#include<math.h> //Incluimos la libreria que nos ayudar� con las operaciones matem�ticas

int main (){
	int	numb1;
	int	numb2;               //definimos las variabls como enteros
	int	resultado;//definimos la variable en la que se va a almacenar el resultado
	printf ("Ingrese el primer numero:"); //pedimos al usuario que ingrese el primer n�mero a restar
	scanf ("%i",&numb1);//leemos la variable
	printf ("Ingrese el segundo numero:");//pedimos al usuario que ingrese el segundo numero a restar
	scanf ("%i",&numb2);//leemos la segunda variable
	resultado=numb1+numb2;//asignamos la operaci�n matem�tica a realizarse
	printf ("El resultado de la suma es:%i",resultado);//imprimimos el resultado de la operaci�n
	
	return 0;
}
