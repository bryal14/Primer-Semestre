//Crear un codigo que nos permita sumar las horas extras al salario que se asigna normalmente de 240

#include<stdio.h>//aqui agregamos las librerias que vamos a utilizar para entrada y salida de datos
#include <math.h>//aqui agregamos la libreria que vamos a utilizar para operaciones matematicas

int main(){
	int salario;//aqui definimos la primera variable como entera
	int horas_extra; //aqui definimos la segunda variable como entera aqui se asignara las operaciones matematicas
	int horas;//aqui definimos la tercera variable como entera
	printf ("Ingrese el numero de horas trabajadas: ");//aqui le pedimos al usuario que ingrese el n�mero de horas trabajadas
	scanf ("%i",&horas);//aqui leemos la tercera variable
	printf ("Ingrese el numero de horas extras: ");//aqui le pedimos al usuario que ingrese el numero de horas extras que tranajo que normalmente serian 40
	scanf ("%i",&salario);//aqui leemos la primera variable
	
	if (horas<=40)	printf ("Su salario sera de:%i",240);	//colocamos la primera condicion (si/if) y su respectiva impresion si se cumple 	
	if (horas>40)  horas_extra= 240+(15*240);//colocamos la segunda condicion y si se cumple se va a realizar una operacion matematica
		printf("Su salario sera:%i",horas_extra);//mostramos por pantallae el salario mas las horas extras
	return 0;	
}
