//creacion de un codigo que nos permita conocer el metodo de pago de acuerdo al numero  de objetos adquiridos por teclado 
#include<stdio.h>//a�adimos las librerias que nos permiten la entrada y salida de datos

int main(){
	int num1;//definimos la primera variable como entero
	
	printf("Ingrese el numero de articulos si desea pagar: ");//pedimos al usuario que ingrese el numero de objetos adquiridos
	scanf ("%i",&num1);//leemos la primera variable y almacenamos el n�mero antes ingresado
	if (num1<=10)//iniciamos la condicion en este caso si el numero de productos es mayor a 10 
	printf("Su pago debe realizarse en efectivo ");//en caso de cumplirse la condicion imprimiremos que el pago es en efectivo
	else//en caso de que no se cumpla la condicion realizaremos al siguiente accion
	printf("Su pago debe realizarse con tarjeta ");//en caso de cumplirse la condicion imprimiremos que el pago es en tarjeta
	return 0;	
}//finalizamos el proceso o codigo
