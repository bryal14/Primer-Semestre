//creacion de un algoritmo que nos permita conocer el mayor de tres n�meros
#include<stdio.h>//a�adimos las librerias que nos permiten la entrada y salida de datos 

int main(){
	float n1;//definimos la primera variable como flotante en caso de querer utilizar decimales
	float n2;//definimos la segunda variable como flotante en caso de querer utilizar decimales
	float n3;//definimos la tercera variable como fotante en caso de querer utilizar decimales
	
	printf ("Ingrese el primer numero: ");//pedimos al usuario que ingrese el primer n�mero a utilizar 
	scanf ("%f",&n1);//leemos la primera variable y almacenamos el n�mero antes ingresado
	printf ("Ingrese el segundo numero: ");//pedimos al usuario que ingrese el segundo n�mero a utilizar
	scanf ("%f",&n2);//leemos la segunda variable y almacenamos el n�mero antes ingresado
	printf ("Ingrese el tercer numero: ");//pedimos al usuario que ingrese el tercer n�mero a utilizar
	scanf ("%f",&n3);//leemos la tercera variable y almacenamos el n�mero antes ingresado
	if (n1>n2){//iniciamos la condicion en este caso con el numero 1 siendo mayor al n�mero 2
		
	if (n1>n3)//iniciamos la condicion en este caso con el numero 1 siendo mayor al n�mero 3
	printf("El numero mayor es:%f",n1);//en caso de cumplirse la condicion imprimiremos que es mayor el n�mero uno 
	}
	else{//en caso de que no se cumpla la condicion realizaremos al siguiente accion
	if (n2>n3)//iniciamos la condicion en este caso con el numero 2 siendo mayor al n�mero 3
	printf("El numero mayor es:%f",n2);//en caso de cumplirse la condicion imprimiremos que es mayor el n�mero dos
	else//en caso de que no se cumpla la condicion realizaremos al siguiente accion
	printf("El numero mayor es:%f",n3);//en caso de cumplirse la condicion imprimiremos que es mayor el n�mero tres
		}
	return 0;	
}
