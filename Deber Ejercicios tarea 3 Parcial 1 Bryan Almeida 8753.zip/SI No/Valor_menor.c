//creacion de un algoritmo que nos permita saber que n�mero ingrrsasdo por teclado es menor si numero uno o numero 2
#include<stdio.h>//incluimos la libreria para entrada y salida de datos 

int main(){
	float n1;//definimos la primera variable como flotante porque ser� utilizada en una condicion 
	float n2;//definimos la segunda variable como flotante porque ser� utilizada en condicino y no necesito de procesos matem�ticos
	
	printf("Ingrese el primer numero: ");//pedimos al usuario que ingrese el primer n�mero 
	scanf("%f",&n1);//almacenamos este n�mero en la primera variable
	printf("Ingrese el segundo numero: ");//pedimos alusuario que ingrese el segundo n�mero
	scanf("%f",&n2);//almacenamos el segundo n�mero en la segunda variable
	if (n1<n2)//iniciamos la condicion a realizarse en este caso con el numero uno mayor al numero 2
	printf("El primer numero es menor");//en caso de cumplirse la condicion se mostrar� por pantalla esto
	else//iniciamos el accionar en caso de que no se cumpla la primera condicion
	printf("El segundo es menor");//en caso de no cumplirse la primer condicion esto se imprimir� o mostrara por pantalla
	

}
