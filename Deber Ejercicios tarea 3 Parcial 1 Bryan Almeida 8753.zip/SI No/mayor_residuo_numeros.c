//creacion de un codigo que nos permita conocer el mayor de dos n�meros
#include<stdio.h>//a�adimos las librerias que nos permiten la entrada y salida de datos

int main(){
	float num1;//definimos la primera variable como decimal en caso de usar fracciones
	float num2;//definimos la primera variable como decimal en caso de usar fracciones
			
	printf("Ingrese el primer numero: ");//pedimos al usuario que ingrese el primer n�mero a utilizar
	scanf("%f",&num1);//leemos la primera variable y almacenamos el n�mero antes ingresado
	printf("Ingrese el segundo numero: ");//pedimos al usuario que ingrese el segundo n�mero a utilizar
	scanf("%f",&num2);//leemos la segunda variable y almacenamos el n�mero antes ingresado
	if (num1>num2)//iniciamos la condicion en este caso si el numero uno es mayor al numero 2
	printf("El primer numero es mayor");//en caso de cumplirse la condicion imprimiremos que es mayor el n�mero uno
	if (num1<num2)//iniciamos la condicion en este caso si el numero 2 es mayor numero 1
	printf("El segundo numero es mayor");//en caso de cumplirse la condicion imprimiremos que es mayor el n�mero dos
	return 0;
}//finalizamos el proceso o codigo
