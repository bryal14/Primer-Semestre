//un algoritmo que nos permita calcular diferentes areas y realizar distintas operaciones desde un menu de opciones

#include <stdio.h>//incluimos las librerias para entrada y salida de datos
#include <math.h>//incluimos las librerias para entrada y salida de datos

int main(){
	float a1,a2,a3;//definimos las variables a ser utilizadas
	float b,h,l;//definimos las variables a ser utilizadas
	int opcion;//definimos las variables a ser utilizadas
	
	printf("Presione 1 para area del cuadrado: ");
	printf("Presione 2 para area del rectangulo: ");
	printf("Presione 3 para area del triangulo: ");//agregamos el menu de opciones a elegir para las areas deseadas
	scanf("%i",&opcion);
	
	switch(opcion){
	case 1: printf("ingrese un lado cualquiera del cuadrado: ");//mostramos por pantalla lo que se realizara en caso de presionar 1
			scanf("%f",&l);
			a1=l*l;//realizamos la operacion deseada para calcular el area deseada
			printf ("El area del cuadrado es%f ", a1);//imprimirmos elresultado de la operacion
			break;
	case 2:printf("ingrese la base y la altura del rectangulo: ");//mostramos por pantalla lo que se realizara en caso de presionar 2
			scanf("%f",&b);
			scanf("%f",&h);
			a2=b*h;//realizamos la operacion deseada para calcular el area deseada
			printf ("El area del rectangulo es:%f ", a2);//imprimirmos elresultado de la operacion
			break;
	case 3:printf("ingrese la base y la altura del triangulo: ");//mostramos por pantalla lo que se realizara en caso de presionar 3
			scanf("%f",&b);
			scanf("%f",&h);
			a3=(b*h)/2;//realizamos la operacion deseada para calcular el area deseada
			printf("El area del trinagulo es:%f ", a3);//imprimirmos elresultado de la operacion
			break;
	default: puts("Opcion invalida");//imprimirmos lo que deseamos informar en caso de no aplastar ninguna de las opciones establecidas
	
	}
	puts("final del programa");//finalizamos la operacion segun 
	return 0;
	
	
}
