//un algoritmo que nos permita conoceer el inventario de una piscina
#include <stdio.h>

int main(){

	int opcion;//definimos las variables a ser utilizadas
	
	printf("Presione 1 para consultar productos: ");
	printf("Presione 0 para salir del inventario: ");//mostramos por pantalla el menu de opciones
	scanf("%i",&opcion);//almacenamos la eleccion en una de las variables
	
	switch(opcion){
	case 1: puts("Disponemos de tablas||aletas||paletas y dos snorkels");//mostramos por pantalla lo que se realizara en caso de presionar 1
			break;
	case 2:puts("Usted ha salido exitosamente del inventario");//mostramos por pantalla lo que se realizara en caso de presionar 2
			break;
	default: puts("seccion inexistente");//mostramos por pantalla lo que se realizara en caso de no cumplirse ninguno de los parametros establecidos
	
	}
	puts("final del programa");//finalizamos proceso
	return 0;
	
	
}
