//este pseudoc�digo nos permite ver el nombre del mes con tan solo ingresar el numero respetivo al mes.
#include <stdio.h>
int main(){
	int mes;//agregamos las opciones a elegir para las areas deseadas
	
	printf("Escribe el mes del cual desea saber el nombre: ");//pedimos al usuario que ingrese un numero del 1 al12 para conocer le mes
	scanf("%i",&mes);
	
	switch(mes){
	case 1: puts("Enero");//mostramos por pantalla lo que se realizara en caso de presionar 1
			break;
	case 2:puts("Febrero");//mostramos por pantalla lo que se realizara en caso de presionar 2
			break;
	case 3:puts("Marzo");//mostramos por pantalla lo que se realizara en caso de presionar 3
			break;
	case 4:puts("Abril");//mostramos por pantalla lo que se realizara en caso de presionar 4
			break;
	case 5:puts("Mayo");//mostramos por pantalla lo que se realizara en caso de presionar 5
			break;
	case 6:puts("Junio");//mostramos por pantalla lo que se realizara en caso de presionar 6
			break;
	case 7:puts("Julio");//mostramos por pantalla lo que se realizara en caso de presionar 7
			break;
	case 8:puts("Agosto");//mostramos por pantalla lo que se realizara en caso de presionar 8
			break;
	case 9:puts("Septiembre");//mostramos por pantalla lo que se realizara en caso de presionar 9
			break;
	case 10:puts("Octubre");//mostramos por pantalla lo que se realizara en caso de presionar 10
			break;
	case 11:puts("Noviembre");//mostramos por pantalla lo que se realizara en caso de presionar 11
			break;
	case 12:puts("Diciembre");//mostramos por pantalla lo que se realizara en caso de presionar 12
			break;
	default: puts("mes inexistente");//mostramos por pantalla lo que se realizara en caso de no cumplirse la condicon
	
	}
	puts("final del programa");//finalizamos el programa
	return 0;
	
	
}
