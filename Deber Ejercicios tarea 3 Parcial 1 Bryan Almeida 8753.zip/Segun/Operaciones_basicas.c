//pseudoc�digo nos permite realizar una operacion matematica dependiendo la elecion del usuario
#include <stdio.h>//incluimos las librerias a ser utilizadas
#include <math.h>//incluimos las librerias a utilizarse en entrada y salida de datos

int main(){
	float suma,resta,multiplicacion,division;//definimos las variables como flotantes en caso de usar decimales
	float n1,n2;//definimos las variables como flotantes en caso de usar decimales
	int opcion;//definimos las variables como entero
	
	printf("Presione 1 para realizar una suma: ");
	printf("Presione 2 para realizar una resta: ");
	printf("Presione 3 para realizar una multiplicacion: ");
	printf("Presione 4 para realizar una multiplicacion: ");//agregamos el menu de opciones a elegir para las areas deseadas
	scanf("%i",&opcion);//almacenamos la eleccion en una de las variables
	
	switch(opcion){
	case 1: printf("ingrese los numeros a sumar: ");//mostramos por pantalla lo que se realizara segun la operacion asignada
			scanf("%f",&n1);
			scanf("%f",&n2);
			suma=n1+n2;
			printf ("el resultado de la suma es%f ", suma);//mostramos por pantalla la respuesta de dicha operacion
			break;
	case 2:printf("ingrese los numeros a restar: ");//mostramos por pantalla lo que se rearealizara segun la operacion asignada
			scanf("%f",&n1);
			scanf("%f",&n2);
			resta=n1-n2;
			printf ("el resultado de la resta es%f ", resta);//mostramos por pantalla la respuesta de dicha operacion
			break;
	case 3:printf("ingrese los numeros a multiplicar: ");//mostramos por pantalla lo que se rearealizara segun la operacion asignada
			scanf("%f",&n1);
			scanf("%f",&n2);
			multiplicacion=n1*n2;
			printf("el resultado de la multiplicacion es%f ", multiplicacion);//mostramos por pantalla la respuesta de dicha operacion
			break;
	case 4:printf("ingrese los numeros a dividir: ");//mostramos por pantalla la operacion asignada
			scanf("%f",&n1);
			scanf("%f",&n2);
			division=n1/n2;
			printf("el resultado de la division es%f ", division);//mostramos por pantalla la respuesta de dicha operacion
			break;
	default: puts("Opcion invalida");//mostramos por pantalla lo que realizara en caso de no teclear ninguna de las opciones
	
	}
	puts("final del programa");
	return 0;
	
	
}
