//un codigo o algoritmo que nos permita conocer el repositorio de una bibioteca
#include <stdio.h>

int main(){
	int musica;//definimos las variables a ser utilizadas
	int arte;//definimos las variables a ser utilizadas
	int biologia;//definimos las variables a ser utilizadas
	int calculo;//definimos las variables a ser utilizadas
	int opcion;//definimos las variables a ser utilizadas
	
	printf("Presione 1 para libros de musica: ");//agregamos el menu de opciones a elegir para las areas deseadas
	printf("Presione 2 para libros de arte: ");//agregamos el menu de opciones a elegir para las areas deseadas
	printf("Presione 3 para libros de biologia: ");//agregamos el menu de opciones a elegir para las areas deseadas
	printf("Presione 4 para libros de calculo: ");//agregamos el menu de opciones a elegir para las areas deseadas
	printf("Presione 0 para salir: ");//agregamos el menu de opciones a elegir para las areas deseadas
	scanf("%i",&opcion);//almacenamos la eleccion en una de las variables
	
	switch(opcion){
	case 1: puts("Elvis, la Construccion del Mito|| �ltimo Tren a Memphis|| La venganza de las punks CONTRA");//mostramos por pantalla lo que se realizara en caso de presionar 1
			break;
	case 2:puts("HISTORIA IRREVERENTE DEL ARTE|| MEMORIAS DE UN LUTHIER,");//mostramos por pantalla lo que se realizara en caso de presionar 2
			break;
	case 3:puts("Libros de Bacteriolog�a||Libros de Biolog�a Ambiental||Libros de Biolog�a Animal ");//mostramos por pantalla lo que se realizara en caso de presionar 3
			break;
	case 4:puts("C�lculo de James Stewart||C�lculo de Louis Leithold||C�lculo de Tom Apostol||Vol 1 y 2 ");//mostramos por pantalla lo que se realizara en caso de presionar 4
			break;
	case 0:puts("Usted salio de la libreria ");//mostramos por pantalla lo que se realizara en caso de presionar 0
			break;		
	default: puts("seccion inexistente");//imprimirmos lo que deseamos informar en caso de no aplastar ninguna de las opciones establecidas
	
	}
	puts("final del programa");//finalizamos la proceso 
	return 0;
	
	
}
