//nombramos el codigo
#include<stdio.h>//incluimos las librearias a utilizar

int main(){
	int num1,num2;//indicamos las variables y su tipo a ser empleadas
	int i;//indicamos la variable auxiliar
	printf("Ingrese los numeros de los cuales desea conocer ls impares: ");//indicamos al usuario que numero desea conocer como impares
	scanf("%i",&num1);
	scanf("%i",&num2);//leemos las variables en las que se almasenaran los numeros
	for ( i = num1; i<=num2; i++)//iniciamos el bucle para ubicar la condicion 
	if (i%2 == 1)//abrimos un condicional 
	printf ("Los numeros pares son:%d\n",i);//imprimirmos el resultado de la operacion
	return 0;
}

