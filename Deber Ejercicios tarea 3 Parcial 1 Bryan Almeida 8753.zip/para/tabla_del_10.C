#include<stdio.h>//incluimos las librearias a utilizar
#include<math.h>//incluimos las librearias a utilizar

int main(){
	int n1;//indicamos las variables y su tipo a ser empleadas
	int i;//indicamos las variables y su tipo a ser empleadas
	printf ("Ingrese el numero del cual desea la tabla inversa: ");
	scanf ("%d",&n1);//leemos las variables en las que se almasenaran los numeros
	for ( i = 1 ;i <= 100; i++)//iniciamos el bucle para ubicar la condicion 
	printf (" \n%d x %d= %d ",n1,i,n1*i);//imprimirmos el resultado de la operacion
	return 0;	
	
}
