#include<stdio.h>
#include<math.h>
float litros(){
	float l,medio,g;
	medio=l/2;
	g=medio*0264172;
	return g;
} 
float imprimir(){
	float l;
	printf("los galones son: %f\n",l);
	return;
}
void leer(){
	float  l;
	printf("ingrese la cantidad de litros: \n");
	scanf("%f",&l);
}
int main(){
	leer();
	litros();
	imprimir();
	return 0;
}
