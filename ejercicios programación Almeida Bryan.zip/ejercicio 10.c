#include <stdio.h>
void obtenerFraccion(float decimal, int* numerador, int* denominador);
void leerDecimal(float* decimal);
void imprimirFraccion(int numerador, int denominador);
void leerDecimal(float* decimal) {
    printf("Ingrese un numero decimal de hasta 2 digitos: ");
    scanf("%f", decimal);
}

void obtenerFraccion(float decimal, int* numerador, int* denominador) {
    if (decimal == 0) {
        *numerador = 0;
        *denominador = 1;
    } else if (decimal >= 10 && decimal <= 99) {
        *numerador = (int)decimal;
        *denominador = 100;
    } else if (decimal >= 1 && decimal <= 9) {
        *numerador = (int)(decimal * 10);
        *denominador = 10;
    } else {
        printf("numero invalido\n");
        *numerador = 0;
        *denominador = 0;
    }
}

void imprimirFraccion(int numerador, int denominador) {
    printf("La fraccion equivalente es: %d/%d\n", numerador, denominador);
}

int main() {
    float decimal;
    int numerador, denominador;

    leerDecimal(&decimal);
    obtenerFraccion(decimal, &numerador, &denominador);
    imprimirFraccion(numerador, denominador);

    return 0;
}
