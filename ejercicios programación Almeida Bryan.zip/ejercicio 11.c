#include <stdio.h> 

void menu ();
void triangulo();
void rectangulo();
void cuadrado();
void circulo();

int main(){
	
	menu();

return 0;
}

void menu (int opcion){
	printf("\n\n**********************************UNIVERSIDAD DE LAS FUERZAS ARMADAS*******************************\n");
	printf("\npresione (1) para calcular el area del triangulo\n");
	printf("\npresione (2) para calcular el area del cuadrado\n"); 
	printf("\npresione (3) para calcular el area del rectangulo\n");
	printf("\npresione (4) para calcular el area del circulo\n");
	printf("\npresione (5) para salir del programa\n");
	scanf ("%i",&opcion);
	switch (opcion){
		
		case 1 : 
		triangulo(); 
		break;
		case 2 :
		cuadrado(); 
		break;	
		case 3 : 
		rectangulo();
		break;	
		case 4 : 
		circulo();
		break;
		case 5 : 
		printf("Usted ha salido exitosamente");
		break;
		default : 
		printf ("Valor no valido: ");
		break;
	}	
}

void triangulo(){
	int l1,l2,result;
	printf ("Ingrese la base y la altura\n");
	scanf ("%i",&l1);
	scanf ("%i",&l2);
	result=(l1*l2)/2;
	printf ("El area del triagulo es:%i\n",result);
}
void rectangulo(){
	int l1,l2,result;
	printf ("Ingrese la base y la altura\n");
	scanf ("%i",&l1);
	scanf ("%i",&l2);
	result=(l1*l2);
	printf ("El area del rectagulo es:%i",result);
}
void cuadrado(){
	int l1,l2,result;
	printf ("Ingrese la base y la altura\n");
	scanf ("%i",&l1);
	result=l1*l1;
	printf ("El area del cuadrado es:%i",result);
}
void circulo(){
	int radio,result;
	int PI=3.1415926535897;
	
	printf ("Ingrese la base y la altura\n");
	scanf ("%i",&radio);
	result=PI*(radio*radio);
	printf ("El area del cuadrado es:%i",result);
}
