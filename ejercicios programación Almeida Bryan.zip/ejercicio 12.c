#include <stdio.h>

int calcularPotencia(int base, int exponente) {
    int resultado = 1;
    
    while (exponente > 0) {
        resultado *= base;
        exponente--;
    }
    
    return resultado;
}

void imprimirResultado(int base, int exponente, int potencia) {
    printf("El resultado de es: %d\n", potencia);
}

int leerNumero(const char* mensaje) {
    int numero;
    
    printf("%s", mensaje);
    scanf("%d", &numero);
    
    return numero;
}

int main() {
    int base, exponente;
    
    base = leerNumero("Ingrese la base: ");
    exponente = leerNumero("Ingrese el exponente: ");
    
    int potencia = calcularPotencia(base, exponente);
    
    imprimirResultado(base, exponente, potencia);
    
    return 0;
}
