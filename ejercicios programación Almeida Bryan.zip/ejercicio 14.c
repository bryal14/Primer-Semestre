#include <stdio.h>
void imprimirResultado(int numero, int factorial);
int leerNumero(int * mensaje);
int calcularFactorial(int numero);

int calcularFactorial(int numero) {
    int factorial = 1;

    while (numero > 0) {
        factorial *= numero;
        numero--;
    }

    return factorial;
}

void imprimirResultado(int numero, int factorial) {
    printf("El factorial de es: %i\n", factorial);
}

int leerNumero(int * mensaje) {
    int numero;

    printf("%s", mensaje);
    scanf("%d", &numero);

    return numero;
}

int main() {
    int numero;

    numero = leerNumero("Ingrese un numero entero positivo: ");

    if (numero<0) {
        printf("Error: el \n");
        return 1;
    }

    int factorial = calcularFactorial(numero);

    imprimirResultado(numero, factorial);

    return 0;
}
