#include <stdio.h>
#include <math.h>

void leernumero(int *numero);
void leerindice(int *indice);
double calcularRaiz(double numero, int indice);
void imprimirRaiz(double raiz);

int main() {
    int numero, indice;
    double raiz;

    leernumero(&numero);
    leerindice(&indice);
    raiz = calcularRaiz(numero, indice);
    imprimirRaiz(raiz);

    return 0;
}

void leernumero(int *numero) {
    printf("Ingrese un numero: ");
    scanf("%d", numero);
}

void leerindice(int *indice) {
    printf("Ingrese el indice de la raiz: ");
    scanf("%d", indice);
}

double calcularRaiz(double numero, int indice) {
    return pow(numero, 1.0 / indice);
}

void imprimirRaiz(double raiz) {
    printf("La raiz es: %.2f\n", raiz);
}
