#include <stdio.h>
#include<math.h>
float metro(float m, float* ml);
void imprimir(float ml);
void leer(float* m, float* ml);

int main() {
    float ml, m;
    leer(&ml, &m);
    imprimir(ml);
    return 0;
}

void leer(float* m, float* ml) {
    printf("Ingrese los metros: ");
    scanf("%f", m);
}

float metro(float m, float* ml) {
    *ml = m * 1000;
    return *ml;
}

void imprimir(float ml) {
    printf("metros transformados a milimetros son: %f\n", ml);
}
