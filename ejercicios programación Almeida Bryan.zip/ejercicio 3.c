#include <stdio.h>
#include <stdlib.h>

int jubilacion(int anoIngreso, int *anoservicio, int *anojubilacion);
void imprimir(int anoservicio, int anojubilacion);
void leer(int *anoIngreso);

int main() {
    int anoIngreso, anoservicio, anojubilacion;

    leer(&anoIngreso);
    jubilacion(anoIngreso, &anoservicio, &anojubilacion);
    imprimir(anoservicio, anojubilacion);

    return 0;
}

int jubilacion(int anoIngreso, int *anoservicio, int *anojubilacion) {
    int anoactual = 2023;
    *anoservicio = anoactual - anoIngreso;
    *anojubilacion = anoIngreso + 30;
    return;
}

void imprimir(int anoservicio, int anojubilacion) {
    printf("Anos de servicio: %d\n", anoservicio);
    printf("Ano de jubilacion: %d\n", anojubilacion);
}

void leer(int *anoIngreso) {
    printf("Ingrese el ano de ingreso a trabajar: ");
    scanf("%d", anoIngreso);
}
