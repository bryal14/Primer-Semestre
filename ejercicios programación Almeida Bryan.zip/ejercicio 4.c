#include <stdio.h>

void leer(char nombre[], int *edad, char *genero);
int saludo(char nombre[], int edad, char genero);
int imprimir();

int main() {
    char nombre[20];
    int edad;
    char genero;

    leer(nombre, &edad, &genero);
    saludo(nombre, edad, genero);

    return 0;
}

void leer(char nombre[], int *edad, char *genero) {
    printf("Ingrese su nombre: ");
    scanf("%s", nombre);

    printf("Ingrese su edad: ");
    scanf("%d", edad);

    printf("Ingrese su genero (masculino = M, femenino = F): ");
    scanf(" %c", genero);
}

int saludo(char nombre[], int edad, char genero) {
    if (genero == 'M') {
        if (edad >= 18) {
            printf("Bienvenido %s, usted es una persona adulta.\n", nombre);
        } else {
            printf("Bienvenido %s, usted es menor de edad.\n", nombre);
        }
    } else if (genero == 'F') {
        if (edad >= 18) {
            printf("Bienvenida %s, usted es una persona adulta.\n", nombre);
        } else {
            printf("Bienvenida %s, usted es menor de edad.\n", nombre);
        }
    } else {
        imprimir();
    }
    return;
}

int imprimir() {
    printf("G�nero no v�lido.\n");
    return;
}
