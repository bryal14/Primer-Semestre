#include <stdio.h>

void leerEdad(int *edad);
void verificarvulnerabilidad(int edad);
void imprimirvulnerabilidad();
void imprimircuidado();

int main() {
    int edad;

    leerEdad(&edad);
    verificarvulnerabilidad(edad);

    return 0;
}

void leerEdad(int *edad) {
    printf("Ingrese su edad: ");
    scanf("%i", edad);
}

void verificarvulnerabilidad(int edad) {
    if (edad >= 65) {
        imprimirvulnerabilidad();
    } else {
        imprimircuidado();
    }
}

void imprimirvulnerabilidad() {
    printf("Cuidado, usted es una persona vulnerable al Coronavirus.\n");
}

void imprimircuidado() {
    printf("Cuidese usted, para que proteja a sus mayores.\n");
}
