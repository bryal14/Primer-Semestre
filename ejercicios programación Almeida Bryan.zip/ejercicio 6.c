#include <stdio.h>

void leerNumero(int *num);
int verificarMultiploRango(int num);
void imprimirMensajeMultiploRango();
void imprimirMensajeNoMultiplo();
void imprimirMensajeFueraRango();

int main() {
    int num;

    leerNumero(&num);
    int resultado = verificarMultiploRango(num);

    if (resultado == 0) {
        imprimirMensajeMultiploRango();
    } else if (resultado == 1) {
        imprimirMensajeNoMultiplo();
    } else {
        imprimirMensajeFueraRango();
    }

    return 0;
}

void leerNumero(int *num) {
    printf("Ingrese un numero: ");
    scanf("%i", num);
}

int verificarMultiploRango(int num) {
    if (num % 25 == 0 && num >= 400 && num <= 700) {
        return 0; // Multiplo y dentro del rango
    } else {
        if (num % 25 != 0) {
            return 1; // No es m�ltiplo
        }
        if (num < 400 || num > 700) {
            return 2; // Fuera del rango
        }
    }
}

void imprimirMensajeMultiploRango() {
    printf("El numero es multiplo de 25 y esta dentro del rango.\n");
}

void imprimirMensajeNoMultiplo() {
    printf("El numero no es multiplo de 25.\n");
}

void imprimirMensajeFueraRango() {
    printf("El numero no esta en el rango entre 400 y 700.\n");
}
