#include <stdio.h>

void leer(int *base, int *potencia);
long calcularPotencia(int base, int potencia);
void imprimir(int base, int potencia, long resultado);

int main() {
    int base, potencia;
    long resultado;

    leer(&base, &potencia);
    resultado = calcularPotencia(base, potencia);
    imprimir(base, potencia, resultado);

    return 0;
}

void leer(int *base, int *potencia) {
    printf("Ingrese la base: ");
    scanf("%d", base);

    printf("Ingrese la potencia: ");
    scanf("%d", potencia);
}

long calcularPotencia(int base, int potencia) {
    long resultado = 1;
    int n; 
    for (n=1; n<=potencia; n++) {
        resultado *= base;
    }
    
    return resultado;
}

void imprimir(int base, int potencia, long resultado) {
    printf("El resultado de %d a la potencia %d es: %d\n", base, potencia, resultado);
}
