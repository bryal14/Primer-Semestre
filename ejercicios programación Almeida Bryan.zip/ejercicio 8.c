#include <stdio.h>

void imprimirmultiplos();
void imprimirResultado(int a);

int main() {
    imprimirmultiplos();
    return 0;
}

void imprimirmultiplos() {
    int a;

    for (a = 900; a >= 700; a--) {
        if (a % 4 == 0) {
            imprimirResultado(a);
        }
    }
    printf("\n");
    return;
}

void imprimirResultado(int a) {
    printf("%d ", a);
}
