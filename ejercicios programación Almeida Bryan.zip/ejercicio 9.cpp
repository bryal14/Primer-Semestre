#include <stdio.h>

void leernumeros(int numeros[], int tam);
int encontrarmayor(const int numeros[], int tam);
void imprimirmayor(int mayor);

int main() {
    int numeros[5];
    int mayor;

    leernumeros(numeros, 5);
    mayor = encontrarmayor(numeros, 5);
    imprimirmayor(mayor);

    return 0;
}

void leernumeros(int numeros[], int tam) {
    printf("Ingrese 5 numeros positivos enteros:\n");

    for (int i = 0; i < tam; i++) {
        printf("Numero %d: ", i + 1);
        scanf("%d", &numeros[i]);
    }
}

int encontrarmayor(const int numeros[], int tam) {
    int mayor = numeros[0];
    
    for (int i = 1; i < tam; i++) {
        if (numeros[i] > mayor) {
            mayor = numeros[i];
        }
    }
    
    return mayor;
}

void imprimirmayor(int mayor) {
    printf("El numero mayor es: %d\n", mayor);
}
