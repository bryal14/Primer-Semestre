#include <stdio.h>

int calcularCuadrado(int lado);
void mostrarResultados(int lado, int perimetro, int superficie);

int main() {
    int lado;
    printf("Ingrese el lado del cuadrado: ");
    scanf("%d", &lado);

    calcularCuadrado(lado);

    return 0;
}

int calcularCuadrado(int lado) {
    int perimetro = 4 * lado;
    int superficie = lado * lado;

    mostrarResultados(lado, perimetro, superficie);
    return;
}

void mostrarResultados(int lado, int perimetro, int superficie) {
    printf("Lado del cuadrado: %d\n", lado);
    printf("Perimetro del cuadrado: %d\n", perimetro);
    printf("Superficie del cuadrado: %d\n", superficie);
}
